Компиляция на Code::Blocks:
https://www.sfml-dev.org/tutorials/2.5/start-cb.php

Компиляция на Linux:
https://www.sfml-dev.org/tutorials/2.5/start-linux.php

Пример программы:
Primer/Primer.cpp

Помощь по функциям:
Help.cpp

Проект:
TanksClass.cpp
TanksClass.hpp
map.hpp
