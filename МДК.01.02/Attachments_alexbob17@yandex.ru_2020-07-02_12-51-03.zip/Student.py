#=========================
#Билет №17
#Выполнил Бобнев Алексей
#П1-17 02.07.2020
#=========================

class Student:
    def __init__(self, Familia, Gruppa, Studbilet):
        self.Familia = Familia
        self.Gruppa = Gruppa
        self.Studbilet = Studbilet

    def ct(self):
        f = open('student.txt', 'r', encoding = 'utf-8')
        f1 = f.read()
        f.close()
        print(f1)

    def clicked(self, Familia, Gruppa, Studbilet):#Добавление в файл
        z = open('student.txt', 'a', encoding = 'utf-8')
        z1 = self.Familia + " " + self.Gruppa + " " + self.Studbilet + '\n'
        z.write(z1)
        z.close()

    def vibor(self):#Выбор студента
        f = open('student.txt', 'r', encoding = 'utf-8')
        f1 = f.read()
        f2 = f1.split()
        f.close()
        print("Введите группу")
        v = input()
        for i in range(len(f2)):
            if (f2[i] == v):
                t = f2[i - 1] + " " + f2[i] + " " + f2[i + 1] + '\n'
        print(t)
         
print("Введите фамилия студента, группу и студенческий билет")
f = input()
g = input()
b = input()
p1 = Student(f, g, b)
p1.ct()
p1.clicked(f, g, b)
p1.ct()
p1.vibor()
